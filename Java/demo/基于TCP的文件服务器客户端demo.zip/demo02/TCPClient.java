package demo02;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.util.ArrayList;

/*
 * 客户端：
 * 1. 本地输入流读取文件
 * 2. 网络IO输出流，将本地输入流传递给服务器
 * 3. 关闭资源
 * */
public class TCPClient {
    public static void main(String[] args) throws IOException, InterruptedException {
        InputStream local = new FileInputStream("a.png");
        Socket client = new Socket("192.168.1.153", 12345);
        OutputStream os = client.getOutputStream();

        int len = 0;
        byte[] cur = new byte[1024];
        while((len = local.read(cur)) != -1) {
            os.write(cur, 0, len);
        }
        client.shutdownOutput();

        Thread.sleep(1000);

        InputStream is = client.getInputStream();
        while((len = is.read(cur)) != -1){
            System.out.println(new String(cur, 0, len));
        }

        os.close();
        is.close();
        local.close();
        client.close();
    }
}
