package demo02;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;

public class TCPServer {
    public static void main(String[] args) throws IOException, InterruptedException {
        ServerSocket serverSocket = new ServerSocket(12345);
        while(true){
            Socket client = serverSocket.accept();
            new Thread(()->{
                try {
                    InputStream is  = client.getInputStream();
                    OutputStream local  = new FileOutputStream( System.currentTimeMillis() + "b.png");
                    int len = 0;
                    byte[] cur = new byte[1024];
                    while((len=is.read(cur)) != -1){
                            local.write(cur, 0, len);
                    }
                    OutputStream os  = client.getOutputStream();
                    os.write("接收完毕".getBytes());
                    client.shutdownOutput();
                    
                    is.close();
                    os.close();
                    local.close();
                    client.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }).start();
        }
    }
}
