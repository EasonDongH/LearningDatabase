﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MS.Models
{
    public enum OperateMode
    {
        Add, 
        Modify, 
        Query
    }
}
